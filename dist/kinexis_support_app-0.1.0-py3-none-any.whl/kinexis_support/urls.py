from django.urls import path
from . import views

urlpatterns = [
    path("health/", views.health, name="kinexis-support-health"),
]